# Detailed stumps for Hitman Cricket

Copy `wicket.ts` to `src/scene/wicket.ts`. It imports the existing `Batch` and
`soft` helpers from `./build`. A copy of `build.ts` is included for reference;
your Hitman Cricket project already has it.

In `src/scene/GameScene.ts`, add:

```ts
import { buildWicket } from './wicket';
```

Replace the existing `wicket` method with:

```ts
private wicket(z: number) {
  const bails = buildWicket(this.world, GAME.stumpHeight, z);
  if (z === 0) this.bails.push(...bails);
}
```

Keep the existing `this.wicket(0); this.wicket(18.7);` calls. The existing
bail reset and bowled animations work unchanged: the returned meshes retain
their original positions, rotation axes and spacing.

Includes turned stump crowns, painted rings and marks, and wooden bails with
narrow spigots. The fixed stump details are batched into two meshes per wicket;
the two bails stay separate so they can animate independently.

This is a code handoff only. It does not deploy or change production.
